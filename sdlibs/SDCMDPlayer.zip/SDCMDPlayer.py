import sys
import os
import subprocess
import zipfile
import requests

def download_and_extract(url, dest_dir):
    # Download the zip file
    response = requests.get(url)
    zip_path = "SDCMDPLAYER.zip"
    
    # Save the zip file to the current directory
    with open(zip_path, 'wb') as f:
        f.write(response.content)
    
    # Create the destination directory if it doesn't exist
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    # Extract the contents into the destination directory
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(dest_dir)
    
    # Optionally, remove the zip file after extraction
    os.remove(zip_path)

download_and_extract("https://alexidians.github.io/SD-CMD-Player/SDCMDPLAYER.zip", "SDCMDPlayer")

LibPath = os.path.abspath(".")
if sys.frozen:
    print("The library 'SDCMDPlayer' cannot run in frozen mode. Please run it with a python runtime instead.")

class SDCMDPlayerMediaUnsupported(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class SDCMDPlayerInstance(AllowNonImageMedia):
    def __init__(self):
        self.AllowNonImageMedia = AllowNonImageMedia
        self.file_path = None
        self.prompt_range = False
        self.prompt_font = False
        self.insta_print = False
        self.color = True
        self.autoreplay = False
        self.framedelay = None
        self.char_light = True
        self.generator_path = None
        self.console_text_dump = False
        self.png_dump = False
    
    def generate_args(self):
        if not self.file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            if not self.file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.mp4', '.avi', '.mov')):
                raise SDCMDPlayerMediaUnsupported("The media type is not supported by SDCMDPlayer")
            if not self.AllowNonImageMedia:
                raise SDCMDPlayerMediaUnsupported("The media is not image and non-image media is disabled.")
        args = [self.file_path]
        if self.insta_print:
            args.extend(["--insta-print"])
        if not self.color:
            args.extend(["--no-color"])
        if self.autoreplay:
            args.extend(["--autoreplay"])
        if not self.char_light:
            args.extend(["--disable-char-lighting"])
        if self.prompt_range:
            args.extend(["--prompt-range"])
        if self.prompt_font:
            args.extend(["--prompt-font"])
        if self.generator_path:
            args.extend(["--generator", str(self.generator_path)])
        if self.framedelay:
            args.extend(["--framedelay", str(self.framedelay)])
        if self.console_text_dump:
            args.extend(["--console-text-dump"])
        if self.png_dump:
            args.extend(["--png-dump"])
        return args
    
    def generate_command(self):
        command = [sys.executable, os.path.join(LibPath, "SDCMDPlayer/SDCMDPlayer.py")]
        command.extend(generate_args())
        return command
    
    def run(self):
        result = subprocess.run(command, capture_output=True, text=True)
        output = {
         "text": result,
         "png_dump": None,
         "console_text_dump": None
        }
        if self.png_dump:
            output.png_dump = self.file_path + "-png-dump.png"
        if self.console_text_dump:
            output.console_text_dump = self.file_path = "-console-text-dump.json"
         
        return output
        
        

class SDCMDPlayer():
    def __init__(self):
        self.AllowNonImageMedia = False
    
    def newInstance(self):
        if sys.frozen:
            print("The library 'SDCMDPlayer' cannot run in frozen mode. Please run it with a python runtime instead.")
            exit()
        return SDCMDPlayerInstance(self.AllowNonImageMedia)
        