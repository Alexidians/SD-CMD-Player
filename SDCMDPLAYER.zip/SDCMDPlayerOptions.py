import easygui
import sys
import subprocess

def main():
    # File selection
    file_types = ["*.png", "*.jpg", "*.jpeg", "*.bmp", "*.gif", "*.mp4", "*.avi", "*.mov"]
    selected_file = easygui.fileopenbox(msg="Select a file", title="File Selection", filetypes=file_types)
    
    if not selected_file:
        easygui.msgbox("No file selected. Exiting...", title="Error")
        return

    # Option mappings (Each option is mapped to its respective command-line flag)
    options_mapping = {
        "Instant Draw": "--insta-print",
        "No Color": "--no-color",
        "AutoReplay": "--auto-replay",
        "Console Text Dump": "--console-text-dump",
        "Png Dump (Image Only)": "--png-dump",
        "Disable Character Lighting": "--disable-char-lighting"
    }

    # Present the user with the option choices
    options = list(options_mapping.keys())
    selected_options = easygui.multchoicebox(msg="Select options", title="Options Selection", choices=options)

    # Generate command format based on selected options
    if not selected_options:
        selected_options_cmd = ""
    else:
        # Map the selected options to their corresponding command-line flags
        selected_options_cmd = " ".join([options_mapping[opt] for opt in selected_options])

    # Generate the final command
    command = f"{sys.executable} SDCMDPlayer.py {selected_file} {selected_options_cmd}"
    choice = easygui.buttonbox(f"Generated Command:\npython SDCMDPlayer.py {selected_file} {selected_options_cmd}", title="Generated Command", choices=["Exit", "Execute"])
    if choice == "Exit":
        exit()
    elif choice == None:
        exit()
    else:
        print("Executing The command. this may take a bit.")

    # Execute the command
    try:
        subprocess.run(command, check=True, shell=True)
        input()
    except subprocess.CalledProcessError as e:
        easygui.msgbox(f"Error executing the command: {str(e)}", title="Error")
        input()

if __name__ == "__main__":
    main()
