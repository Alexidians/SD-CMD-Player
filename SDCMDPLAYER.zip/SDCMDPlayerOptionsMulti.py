import easygui
import sys
import subprocess
from concurrent.futures import ThreadPoolExecutor

def execute_command(command):
    try:
        subprocess.run(command, check=True, shell=True)
    except subprocess.CalledProcessError as e:
        easygui.msgbox(f"Error executing the command: {str(e)}", title="Error")

def main():
    # File selection
    file_types = ["*.png", "*.jpg", "*.jpeg", "*.bmp", "*.gif", "*.mp4", "*.avi", "*.mov"]
    selected_files = easygui.fileopenbox(msg="Select files", title="File Selection", filetypes=file_types, multiple=True)
    
    if not selected_files:
        easygui.msgbox("No files selected. Exiting...", title="Error")
        return

    # Option mappings (Each option is mapped to its respective command-line flag)
    options_mapping = {
        "Instant Draw": "--insta-print",
        "No Color": "--no-color",
        "AutoReplay": "--auto-replay",
        "Console Text Dump": "--console-text-dump",
        "Png Dump (Image Only)": "--png-dump",
        "Disable Character Lighting": "--disable-char-lighting"
    }

    # Present the user with the option choices
    options = list(options_mapping.keys())
    selected_options = easygui.multchoicebox(msg="Select options", title="Options Selection", choices=options)

    # Generate command format based on selected options
    if not selected_options:
        selected_options_cmd = ""
    else:
        # Map the selected options to their corresponding command-line flags
        selected_options_cmd = " ".join([options_mapping[opt] for opt in selected_options])

    # Create the list of commands
    commands = [f"{sys.executable} SDCMDPlayer.py {file} {selected_options_cmd}" for file in selected_files]

    # Confirm command execution
    command_preview = "\n".join(commands)
    choice = easygui.buttonbox(f"Generated Commands:\n{command_preview}", title="Generated Commands", choices=["Exit", "Execute"])
    if choice == "Exit":
        exit()
    elif choice is None:
        exit()
    else:
        print("Executing the commands. This may take a bit.")

    # Execute commands in parallel
    with ThreadPoolExecutor() as executor:
        futures = [executor.submit(execute_command, command) for command in commands]
        for future in futures:
            future.result()  # Wait for all commands to complete

if __name__ == "__main__":
    main()
