import sys
import subprocess
import os
import json
try:
    import numpy as np
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy"])
    import numpy as np
try:
    from PIL import Image
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow"])
    from PIL import Image
    from PIL import Image, ImageDraw, ImageFont
try:
    import imageio
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "imageio"])
    import imageio
try:
    import cv2
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "cv2"])
    import cv2
try:
    import time
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "time"])
    import time
try:
    import keyboard
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "keyboard"])
    import keyboard
try:
    import emoji
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "emoji"])
    import emoji

def save_to_file_json(file_path, data):
    """Convert data to JSON string and save it to a file."""
    try:
        # Convert data to JSON string
        json_data = json.dumps(data, indent=4)
        
        # Write JSON string to file
        with open(file_path, 'w') as file:
            file.write(json_data)
    except Exception as e:
        print(f"An error occurred: {e}")

def save_to_file(file_path, data):
    try:
        with open(file_path, 'w') as file:
            file.write(data)
    except Exception as e:
        print(f"An error occurred: {e}")

def colorize_text(text, r, g, b):
    """ANSI escape sequence for RGB color"""
    return f"\033[38;2;{r};{g};{b}m{text}\033[0m"

def image_to_ascii_html(image, width=80, color=True, disableCharLighting=True):
    """Convert image to ASCII art and output as HTML with a black background"""
    img = image.convert('RGB')
    aspect_ratio = img.height / img.width
    new_width = width
    new_height = int(aspect_ratio * width * 0.55)
    img = img.resize((new_width, new_height))
    
    pixels = np.array(img)
    chars = "@%#*+=-:. "  # ASCII characters from dark to light

    ascii_image = ""
    for row in pixels:
        line = ""
        for pixel in row:
            r, g, b = pixel
            if disableCharLighting:
                ascii_char = "@"
            else:
                intensity = int((r + g + b) / 3 / 255 * (len(chars) - 1))
                ascii_char = chars[intensity]
            if color:
                # Apply color to each ASCII character
                line += f'<b><span style="color: rgb({r},{g},{b});">{ascii_char}</span></b>'
            else:
                line += f'<b>{ascii_char}</b>'
        ascii_image += f'{line}<br>'  # Use <br> for new lines
    
    # Wrap ASCII art in a full HTML document with a black background
    html_template = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ASCII Art</title>
        <style>
            body {{
                background-color: black;
                color: white;
                font-family: monospace;  /* Use fixed-width font */
                white-space: pre;  /* Preserve whitespace and line breaks */
                margin: 0;
                padding: 0;
            }}
            span {{
                font-size: 0.9em;  /* Adjust font size if necessary */
            }}
            b {{
                font-weight: bold;  /* Use <b> for bold text */
            }}
        </style>
    </head>
    <body>
        {ascii_image}
    </body>
    </html>
    """

    return html_template


def is_emoji(character):
    """Check if a character is an emoji using the emoji module."""
    return emoji.is_emoji(character)

def font_exists(font_path):
    """Check if the specified font file exists."""
    return os.path.isfile(font_path)

def image_to_ascii_png(image, width=80, color=True, customRange=None, save_path='ascii_art.png', EmojiRange=False):
    """Convert image to ASCII art with optional color and save as PNG, using a custom range for brightness."""
    default_chars = "@%#*+=-:. "
    chars = customRange if customRange else default_chars

    img = image.convert('RGB')
    aspect_ratio = img.height / img.width
    new_width = width
    new_height = int(aspect_ratio * width * 0.55)
    img = img.resize((new_width, new_height))
    
    pixels = np.array(img)

    ascii_image = []
    for row in pixels:
        line = []
        for pixel in row:
            r, g, b = pixel
            intensity = int((r + g + b) / 3 / 255 * (len(chars) - 1))
            ascii_char = chars[intensity]
            if color:
                line.append((ascii_char, (r, g, b)))
            else:
                line.append((ascii_char, (255, 255, 255)))  # Default to white if no color
        ascii_image.append(line)
    
    def text_to_image(ascii_image, image_file, font_size=12):
        # If EmojiRange is True, use Symbola.ttf, otherwise use default system font
        if EmojiRange:
            try:
                loaded_font = ImageFont.truetype("fonts/Symbola.ttf", font_size)
            except (IOError, OSError):
                print("Emojis will not be supported. Missing Symbola Font.")
                loaded_font = ImageFont.load_default()  # Fallback to system font
        else:
            loaded_font = ImageFont.load_default()  # System default

        emoji_font = loaded_font  # Use the same font for everything in this case

        lines = ascii_image
        max_width = max([sum([loaded_font.getsize(char)[0] for char, _ in line]) for line in lines])
        total_height = sum([loaded_font.getsize(line[0][0])[1] for line in lines])
        img = Image.new('RGB', (max_width, total_height), color='black')
        draw = ImageDraw.Draw(img)
        
        y = 0
        for line in lines:
            x = 0
            for char, color in line:
                try:
                    draw.text((x, y), char, font=loaded_font, fill=color if color else 'white')
                except UnicodeEncodeError:
                    draw.text((x, y), '?', font=loaded_font, fill=color if color else 'white')
                x += loaded_font.getsize(char)[0]
            y += loaded_font.getsize(line[0][0])[1]
        
        img.save(image_file, format='PNG')
    
    text_to_image(ascii_image, save_path)



def image_to_ascii(image, width=80, color=True, customRange=None):
    """Convert image to ASCII art for console output, using a custom range for brightness."""
    # Use default ASCII characters if customRange is None
    default_chars = "@%#*+=-:. "
    chars = customRange if customRange else default_chars

    img = image.convert('RGB')
    aspect_ratio = img.height / img.width
    new_width = width
    new_height = int(aspect_ratio * width * 0.55)
    img = img.resize((new_width, new_height))
    
    pixels = np.array(img)

    ascii_image = ""
    for row in pixels:
        line = ""
        for pixel in row:
            r, g, b = pixel
            # Compute intensity based on the length of the customRange or default range
            intensity = int((r + g + b) / 3 / 255 * (len(chars) - 1))
            ascii_char = chars[intensity]
            if color:
                line += colorize_text(ascii_char, r, g, b)
            else:
                line += ascii_char
        ascii_image += line + "\n"
    
    return ascii_image.strip()

def print_image(ascii_image, insta_print):
    """Prints ASCII image based on insta_print flag"""
    if insta_print:
        print(ascii_image)
    else:
        for line in ascii_image.split('\n'):
            print(line)

def display_image(image_path, color=True, width=80, insta_print=False, autoreplay=False, customRange=None, ConsoleTxtDump=False, pngDump=False, EmojiRange=False):
    """Open and display an image as ASCII"""
    try:
        img = Image.open(image_path)
        ascii_image = image_to_ascii(img, width=width, color=color, customRange=customRange)
        if ConsoleTxtDump:
         save_to_file_json(image_path + "-console-text-dump.json", [ascii_image])
        if pngDump:
         image_to_ascii_png(img, width=width, color=color, customRange=customRange, save_path=image_path + "-png-dump.png", EmojiRange=EmojiRange)
        print_image(ascii_image, insta_print)
        os.system('cls' if os.name == 'nt' else 'clear')
        print_image(ascii_image, insta_print)
        if autoreplay:
         while not keyboard.is_pressed('esc'):
            time.sleep(1)
    except Exception as e:
        print(f"Error displaying image: {e}")
        input("Press enter to continue")

def display_gif(gif_path, color=True, width=80, insta_print=False, autoreplay=True, customRange=None, ConsoleTxtDump=False):
    """Display a GIF, either line by line or instant print"""
    try:
        gif = imageio.mimread(gif_path)
        ascii_frames = [image_to_ascii(Image.fromarray(frame), width=width, color=color, customRange=customRange) for frame in gif]
        if ConsoleTxtDump:
         save_to_file_json(gif_path + "-console-text-dump.json", ascii_frames)
        if autoreplay:
         while not keyboard.is_pressed('esc'):
            for ascii_image in ascii_frames:
                print_image(ascii_image, insta_print)
                # time.sleep(0)
                os.system('cls' if os.name == 'nt' else 'clear')
        else:
            for ascii_image in ascii_frames:
                print_image(ascii_image, insta_print)
                # time.sleep(0)
                os.system('cls' if os.name == 'nt' else 'clear')
    except Exception as e:
        print(f"Error displaying GIF: {e}")
        input("Press enter to continue")

def display_video(video_path, color=True, width=80, insta_print=False, autoreplay=False, customRange=None, ConsoleTxtDump=False):
    """Display a video as ASCII, either line by line or instant print"""
    try:
        cap = cv2.VideoCapture(video_path)
        if autoreplay:
         while cap.isOpened() and not keyboard.is_pressed('esc'):
            ret, frame = cap.read()
            if not ret:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            ascii_image = image_to_ascii(img, width=width, color=color, customRange=customRange)
            print_image(ascii_image, insta_print)
            # time.sleep(0)
            os.system('cls' if os.name == 'nt' else 'clear')
         if not keyboard.is_pressed('esc'):
            display_video(video_path, color, width, insta_print, autoreplay)
        else:
         viddata = []
         while cap.isOpened() and not keyboard.is_pressed('esc'):
            ret, frame = cap.read()
            if not ret:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            ascii_image = image_to_ascii(img, width=width, color=color, customRange=customRange)
            viddata.append(ascii_image)
            print_image(ascii_image, insta_print)
            # time.sleep(0)
            os.system('cls' if os.name == 'nt' else 'clear')

        cap.release()
        if ConsoleTxtDump:
         save_to_file_json(video_path + "-console-text-dump.json", viddata)
    except Exception as e:
        print(f"Error displaying video: {e}")
        input("Press enter to continue")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python script.py <image|video|gif> [--no-color] [--insta-print]")
        sys.exit(1)

    file_path = sys.argv[1]
    sys.set_int_max_str_digits(0)
    customRange = None
    EmojiRange = False
    insta_print = '--insta-print' in sys.argv
    color = '--no-color' not in sys.argv
    autoreplay = '--autoreplay' in sys.argv
    if '--disable-char-lighting' in sys.argv:
        customRange = "@"
    if '--poop' in sys.argv:
        customRange = "💩"
        EmojiRange = True
    ConsoleTxtDump = '--console-text-dump' in sys.argv
    pngDump = '--png-dump' in sys.argv

    # Handle file types (image, gif, or video)
    if file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
        display_image(file_path, color=color, insta_print=insta_print, autoreplay=autoreplay, customRange=customRange, ConsoleTxtDump=ConsoleTxtDump, pngDump=pngDump, EmojiRange=EmojiRange)
    elif file_path.lower().endswith('.gif'):
        display_gif(file_path, color=color, insta_print=insta_print, autoreplay=autoreplay, customRange=customRange, ConsoleTxtDump=ConsoleTxtDump)
    elif file_path.lower().endswith(('.mp4', '.avi', '.mov')):
        display_video(file_path, color=color, insta_print=insta_print, autoreplay=autoreplay, customRange=customRange, ConsoleTxtDump=ConsoleTxtDump)
    else:
        print(f"Unsupported file format: {file_path}")
        input("Press enter to continue")
