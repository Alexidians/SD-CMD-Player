import random
import argparse
import sys

# Emoji dictionary for the valid options
choices = {
    "rock": "🪨",
    "paper": "📄",
    "scissors": "✂️"
}

# Add some "Jokester" options
jokester_choices = ["gun 🔫", "dynamite 💣", "laser 🔥", "shark 🦈"]

def random_bot():
    """Random bot picks from the valid choices."""
    return random.choice(list(choices.keys())), "Random"

def jokester_bot():
    """Jokester bot mixes valid choices with absurd ones."""
    if random.random() < 0.2:  # 20% chance to pick a joke option
        return random.choice(jokester_choices), "Jokester"
    return random.choice(list(choices.keys())), "Jokester"

def hacker_bot(player_choice):
    """Hacker bot always wins, except for a rare hack error."""
    if random.random() < 0.1:  # 10% chance for a 'hack error'
        return player_choice, "Hacker (Hack Error)"

    # Determine the winning move
    if player_choice == "rock":
        return "paper", "Hacker"
    elif player_choice == "paper":
        return "scissors", "Hacker"
    elif player_choice == "scissors":
        return "rock", "Hacker"

def get_winner(player, bot_choice):
    """Determine the winner between the player and the bot."""
    if player == bot_choice:
        return "tie"
    elif (player == "rock" and bot_choice == "scissors") or \
         (player == "paper" and bot_choice == "rock") or \
         (player == "scissors" and bot_choice == "paper"):
        return "player"
    elif bot_choice in choices:
        return "bot"
    else:
        return "joke"

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Play Rock-Paper-Scissors against robots!")
    parser.add_argument("--bot", choices=["random", "jokester", "hacker"], default="random", 
                        help="Choose the bot to play against (default: random).")
    parser.add_argument("--rounds-until-end", type=str, default="inf",
                        help="Number of rounds before the game ends (default: infinite). Use 'inf' for infinite rounds.")
    args = parser.parse_args()

    # Map bot names to functions
    bot_functions = {
        "random": random_bot,
        "jokester": jokester_bot,
        "hacker": hacker_bot
    }

    selected_bot = bot_functions[args.bot]

    # Handle infinite or limited rounds
    if args.rounds_until_end == "inf":
        rounds = float("inf")
    else:
        try:
            rounds = int(args.rounds_until_end)
        except ValueError:
            print("Error: --rounds-until-end must be 'inf' or an integer.", file=sys.stderr)
            sys.exit(1)

    print(f"Playing against the {args.bot.capitalize()} Bot! 🤖")
    print(f"Rounds: {'Infinite' if rounds == float('inf') else rounds}")
    print("Type 'rock', 'paper', or 'scissors' to play. Type 'quit' to exit.\n")

    current_round = 0
    player_wins = 0
    bot_wins = 0
    ties = 0

    while current_round < rounds:
        player_choice = input("\nYour choice (rock/paper/scissors): ").strip().lower()
        if player_choice == "quit":
            print("Thanks for playing! Goodbye! 👋")
            break
        elif player_choice not in choices:
            print("Invalid choice! Please type 'rock', 'paper', or 'scissors'.")
            continue

        # Bot makes a move
        if args.bot == "hacker":
            bot_choice, bot_name = selected_bot(player_choice)  # Hacker needs player's input
        else:
            bot_choice, bot_name = selected_bot()

        # Display choices
        print(f"\nYou chose {choices.get(player_choice, player_choice)} {player_choice.capitalize()}")
        if bot_choice in choices:
            print(f"{bot_name} chose {choices[bot_choice]} {bot_choice.capitalize()}")
        else:
            print(f"{bot_name} chose {bot_choice}")

        # Determine the winner
        result = get_winner(player_choice, bot_choice)
        if result == "player":
            print("You win! 🎉")
            player_wins += 1
        elif result == "bot":
            print("You lose! 😢")
            bot_wins += 1
        elif result == "tie":
            print("It's a tie! 🤝")
            ties += 1
        else:
            print(f"You were obliterated by {bot_choice}! 😨")
            bot_wins += 1

        current_round += 1

    # Display final results
    print("\nGame over! Final results:")
    print(f"Player wins: {player_wins}")
    print(f"Bot wins: {bot_wins}")
    print(f"Ties: {ties}")

    if player_wins > bot_wins:
        print("You are the overall winner! 🏆")
    elif bot_wins > player_wins:
        print(f"The {args.bot.capitalize()} Bot is the overall winner! 💥")
    else:
        print("It's an overall tie! 🔄")

    print("Thanks for playing! 🎮")
    input("Press enter to exit")

if __name__ == "__main__":
    main()
