import random
import os
import keyboard
import time
from collections import deque
import argparse
import json

texturemap = {
 "player": ["@", "@"],
 "end": ["X", "X"],
 "wall": ["#", "#"],
 "empty": [" ", " "]
}

def clear_screen():
    """Clear the console screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def create_maze(width, height):
    """Create a maze with walls (#), an entrance (@), and an exit (X)."""
    maze = [[' ' for _ in range(width)] for _ in range(height)]
    for i in range(height):
        for j in range(width):
            if random.random() < 0.3:  # Increased density of walls
                maze[i][j] = '#'
    maze[0][0] = '@'  # Start position
    maze[height - 1][width - 1] = 'X'  # Exit

    # Ensure the maze is solvable by checking connectivity
    if not is_solvable(maze, (0, 0), (height - 1, width - 1)):
        return create_maze(width, height)  # Retry if not solvable

    return maze

def is_solvable(maze, start, end):
    """Check if there is a path from start to end using BFS."""
    height, width = len(maze), len(maze[0])
    visited = [[False for _ in range(width)] for _ in range(height)]
    queue = deque([start])
    visited[start[0]][start[1]] = True

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # up, down, left, right

    while queue:
        current = queue.popleft()
        if current == end:
            return True

        for direction in directions:
            y, x = current
            new_y, new_x = y + direction[0], x + direction[1]
            if 0 <= new_y < height and 0 <= new_x < width and not visited[new_y][new_x] and maze[new_y][new_x] != '#':
                visited[new_y][new_x] = True
                queue.append((new_y, new_x))

    return False

def get_random_value(arr):
    """Returns a random value from the given array."""
    if arr:  # Check if the array is not empty
        return random.choice(arr)
    else:
        raise ValueError("The array cannot be empty")


def print_maze(maze, player_pos):
    """Print the maze with the player's current position."""
    for y, row in enumerate(maze):
        for x, cellid in enumerate(row):
            if (y, x) == player_pos:
                print(get_random_value(texturemap.get("player", ["@", "@"])), end='')  # Player
            else:
                if cellid == "#":
                    cell = get_random_value(texturemap.get("wall", ["#", "#"]))
                elif cellid == "X":
                    cell = get_random_value(texturemap.get("end", ["X", "X"]))
                elif cellid == "@":
                    cell = get_random_value(texturemap.get("player", ["@", "@"]))
                elif cellid == " ":
                    cell = get_random_value(texturemap.get("empty", [" ", " "]))
                print(cell, end='')
        print()
    print("\nUse arrow keys to move. Close the console to quit.")
    if not args.hide_level_counter:
        print("Current Level:", level_counter)

def move_player(player_pos, direction, maze):
    """Move the player in the given direction if possible."""
    y, x = player_pos
    if direction == 'up' and y > 0 and maze[y - 1][x] != '#':
        y -= 1
    elif direction == 'down' and y < len(maze) - 1 and maze[y + 1][x] != '#':
        y += 1
    elif direction == 'left' and x > 0 and maze[y][x - 1] != '#':
        x -= 1
    elif direction == 'right' and x < len(maze[0]) - 1 and maze[y][x + 1] != '#':
        x += 1
    else:
        return player_pos  # If no movement, return the same position

    clear_screen()  # Only clear screen when player moves
    print_maze(maze, (y, x))  # Print updated maze with new position
    return y, x

def play_game(width, height, levels_until_exit):
    global level_counter
    """Run the maze game."""
    level_counter += 1
    player_pos = (0, 0)

    maze = create_maze(width, height)
    clear_screen()  # Initial screen clear
    print_maze(maze, player_pos)  # Print initial maze

    while player_pos != (height - 1, width - 1):
        move = False
        if keyboard.is_pressed('up'):
            player_pos = move_player(player_pos, 'up', maze)
            move = True
        elif keyboard.is_pressed('down'):
            player_pos = move_player(player_pos, 'down', maze)
            move = True
        elif keyboard.is_pressed('left'):
            player_pos = move_player(player_pos, 'left', maze)
            move = True
        elif keyboard.is_pressed('right'):
            player_pos = move_player(player_pos, 'right', maze)
            move = True

        time.sleep(0.1)  # To prevent too fast polling

    clear_screen()
    print_maze(maze, player_pos)
    print("Congratulations! You found the exit!")
    time.sleep(2)  # Wait a bit before restarting
    if level_counter < levels_until_exit:
        play_game(width, height, levels_until_exit)

def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Maze Game")
    parser.add_argument("--levels_until_exit", type=str, default="inf", help="Number of levels until the game ends (use 'inf' for infinite levels)")
    parser.add_argument("--hide_level_counter", action="store_true", help="Disable level counter display")
    parser.add_argument("--width", type=int, default=60, help="Width of the maze")
    parser.add_argument("--height", type=int, default=20, help="Height of the maze")
    parser.add_argument("--texturemap", type=str, default="", help="Path to the json texture map for the text maze")
    return parser.parse_args()

if __name__ == "__main__":
    level_counter = 0
    args = parse_arguments()
    if args.texturemap != "":
        file = open(args.texturemap, mode="r")
        texturemap = json.loads(file.read())
        file.close()
    levels_until_exit = args.levels_until_exit
    if levels_until_exit == "inf":
        levels_until_exit = float("inf")
    else:
        levels_until_exit = float(levels_until_exit)
    play_game(args.width, args.height, levels_until_exit)
